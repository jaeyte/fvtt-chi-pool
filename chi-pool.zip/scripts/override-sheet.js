Hooks.once("init", async function () {
  const sheetClass = CONFIG.Actor.sheetClasses["character"]["pf2e.CharacterSheetPF2e"][0].cls;

  class ChiPoolSheet extends sheetClass {
    get template() {
      return "modules/chi-pool/templates/custom-sheet.html";
    }

    async getData(options) {
      const data = await super.getData(options);
      const level = getProperty(this.actor.system, "details.level.value") ?? 0;
      const conMod = getProperty(this.actor.system, "abilities.con.mod") ?? 0;
      const autoChi = Math.max(0, Math.floor(level / 2) + conMod);

      const stored = getProperty(this.actor.system, "custom.chiPool") ?? {};
      const manualMode = stored.manual ?? false;
      const value = stored.value ?? autoChi;
      const max = stored.max ?? autoChi;

      data.chiPool = {
        value,
        max,
        manual: manualMode,
        autoValue: autoChi,
        color: max === 0 ? "black" : value / max <= 0.3 ? "red" : value / max >= 0.7 ? "blue" : "black"
      };

      return data;
    }

    activateListeners(html) {
      super.activateListeners(html);
      html.find('input[name="system.custom.chiPool.manual"]').change(this._onToggleManual.bind(this));
      html.find(".chi-pool-adjust.add").click(this._onAddChi.bind(this));
      html.find(".chi-pool-adjust.sub").click(this._onSubChi.bind(this));
    }

    async _onToggleManual(event) {
      const manual = event.currentTarget.checked;
      const level = getProperty(this.actor.system, "details.level.value") ?? 0;
      const conMod = getProperty(this.actor.system, "abilities.con.mod") ?? 0;
      const autoChi = Math.max(0, Math.floor(level / 2) + conMod);

      await this.actor.update({ "system.custom.chiPool": {
        manual,
        value: autoChi,
        max: autoChi
      }});
    }

    async _onAddChi() {
      const val = this.actor.system.custom?.chiPool?.value ?? 0;
      const max = this.actor.system.custom?.chiPool?.max ?? 0;
      if (val < max) {
        await this.actor.update({ "system.custom.chiPool.value": val + 1 });
        this._postMessage(val + 1, max);
      }
    }

    async _onSubChi() {
      const val = this.actor.system.custom?.chiPool?.value ?? 0;
      if (val > 0) {
        await this.actor.update({ "system.custom.chiPool.value": val - 1 });
        this._postMessage(val - 1, this.actor.system.custom?.chiPool?.max ?? 0);
      }
    }

    _postMessage(value, max) {
      ChatMessage.create({
        user: game.user.id,
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        content: `<b>${this.actor.name}</b> now has <strong>${value}/${max}</strong> Chi.`
      });
    }
  }

  Actors.registerSheet("pf2e", ChiPoolSheet, {
    label: "Chi Pool Sheet (PF2e)",
    types: ["character"],
    makeDefault: false
  });

  Hooks.on("updateActor", actor => {
    const chi = actor.system.custom?.chiPool;
    if (!chi || chi.manual) return;
    const level = actor.system.details.level.value;
    const conMod = actor.system.abilities.con.mod;
    const autoChi = Math.max(0, Math.floor(level / 2) + conMod);
    actor.update({ "system.custom.chiPool": { manual: false, value: autoChi, max: autoChi } });
  });
});
